package ca.ubc.cs304.model;

public class Maxid {
    private int maxid;

    public int getMaxid() {
        return maxid;
    }

    public Maxid(int maxid) {
        this.maxid = maxid;
    }
}
